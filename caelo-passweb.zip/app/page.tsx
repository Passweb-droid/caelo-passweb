export default function Home() {
  return (
    <main
      style={{
        minHeight: '100vh',
        padding: '3rem 1.5rem',
        fontFamily: 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
        maxWidth: '960px',
        margin: '0 auto',
        lineHeight: 1.6,
      }}
    >
      <header style={{ marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 700, marginBottom: '0.5rem' }}>
          Caelo PassWeb
        </h1>
        <p style={{ fontSize: '1.1rem', opacity: 0.85 }}>
          Il cervello digitale dedicato al mondo scuola che tiene insieme tutta la normativa
          PassWeb e la rende utilizzabile nella pratica quotidiana, senza perdersi tra circolari,
          messaggi e note.
        </p>
      </header>

      <section style={{ marginBottom: '2.5rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600, marginBottom: '0.5rem' }}>
          A chi si rivolge
        </h2>
        <ul>
          <li>Segreterie scolastiche che gestiscono pratiche PassWeb ogni giorno.</li>
          <li>Dirigenti e DSGA che hanno bisogno di un quadro chiaro e aggiornato.</li>
          <li>
            Consulenti del lavoro, studi e CAF che seguono il personale della scuola e devono
            incrociare INPS, MIM e normativa contrattuale.
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: '2.5rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600, marginBottom: '0.5rem' }}>
          Cosa fa Caelo PassWeb
        </h2>
        <ul>
          <li>Raccoglie circolari, messaggi, note e manuali PassWeb in un unico ambiente.</li>
          <li>
            Collega ogni atto alle norme di riferimento, agli esempi pratici e alle casistiche
            reali.
          </li>
          <li>
            Permette ricerche mirate sul comparto scuola, filtrando il rumore dei contenuti non
            pertinenti.
          </li>
          <li>
            Supporta la preparazione delle pratiche, riduce gli errori e fa risparmiare tempo alle
            segreterie.
          </li>
        </ul>
      </section>

      <section style={{ marginBottom: '2.5rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 600, marginBottom: '0.5rem' }}>
          Stato del progetto e contatti
        </h2>
        <p>
          Stiamo completando il primo prototipo dedicato alle scuole che utilizzano PassWeb per la
          gestione delle posizioni assicurative del personale.
        </p>
        <p>
          Per informazioni, collaborazioni o per prenotare una demo, puoi scrivere a:
        </p>
        <p style={{ fontWeight: 600, marginTop: '0.5rem' }}>
          (qui inseriremo in seguito le email ufficiali di contatto)
        </p>
      </section>

      <footer
        style={{
          borderTop: '1px solid #ddd',
          paddingTop: '1rem',
          fontSize: '0.9rem',
          opacity: 0.7,
          marginTop: '2rem',
        }}
      >
        © {new Date().getFullYear()} Caelo PassWeb – progetto in sviluppo.
      </footer>
    </main>
  );
}